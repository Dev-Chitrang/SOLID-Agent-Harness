import ora from 'ora';
import chalk from 'chalk';
import { readRepositoryFiles, writeReportFile } from '../core/fileSystem.js';
import { AgentHarness } from '../core/harness.js';
import { ProviderFactory } from '../providers/providerFactory.js';
import { ConfigManager } from '../core/config.js';

export async function handleAuditCommand(filePath, providerName, modelName) {
    const spinner = ora('Indexing target repository layout...').start();
    try {
        const configManager = new ConfigManager();
        const globalConfig = configManager.load();
        const activeProviderName = providerName || globalConfig.defaultProvider;
        const providerCreds = globalConfig.providers[activeProviderName];

        if (!providerCreds || !providerCreds.apiKey) {
            spinner.stop();
            console.log(chalk.red(`Error: Provider '${activeProviderName}' is unconfigured. Run 'code-agent init'.\n`));
            return;
        }

        const filePayload = readRepositoryFiles(filePath);
        spinner.text = chalk.cyan(`Repository indexed. Starting SOLID Audit Graph loop via ${activeProviderName}...`);

        const providerInstance = ProviderFactory.create(activeProviderName, providerCreds);
        const harness = new AgentHarness(providerInstance, modelName || providerCreds.defaultModel);

        const markdownOutput = await harness.run('audit', filePayload, filePath);

        writeReportFile(filePath, globalConfig.outputDir || 'Review', 'SOLID_AUDIT.md', markdownOutput);
        spinner.succeed(chalk.green(`Audit evaluation complete. Report written to ${globalConfig.outputDir || 'Review'}/SOLID_AUDIT.md`));
    } catch (error) {
        spinner.fail(chalk.red(`Audit routine aborted: ${error.message}`));
    }
}
